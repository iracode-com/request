<footer class="bottom-0 left-0 z-20 w-full py-2 border-t md:flex md:items-center md:justify-between md:p-6  dark:border-gray-700">
    <span class="text-sm text-gray-500 sm:text-center dark:text-gray-400">{{ verta()->year }} ©
        <a href="#" class="hover:underline">{{ $copyright }}</a>
    </span>
</footer>