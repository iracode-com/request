<div class="relative flex items-center justify-center text-center">
    <div class="absolute border-t border-gray-200 w-full h-px"></div>
    <p class="inline-block relative bg-gray-50 text-sm p-2 rounded-md font-medium text-gray-500 dark:bg-gray-800 dark:text-gray-100">
        <?php echo e(__('Or login via')); ?>

    </p>
</div>

<div class="grid gap-4">
    <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['color' => 'primary','outlined' => true,'tag' => 'a','href' => route('auth.sso.login'),'spaMode' => false,'target' => '_blank']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'primary','outlined' => true,'tag' => 'a','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('auth.sso.login')),'spa-mode' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'target' => '_blank']); ?>
           <span class="flex gap-2 justify-center items-center">
                <img src="<?php echo e(Vite::asset('resources/assets/images/iracode.webp')); ?>" alt="iracode" class="w-8 h-8">
            پنجره هوشمند ایراکد من
           </span>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
</div>
<?php /**PATH E:\Iracode\Projects\request-module\resources\views\components\auth\login-via-sso.blade.php ENDPATH**/ ?>