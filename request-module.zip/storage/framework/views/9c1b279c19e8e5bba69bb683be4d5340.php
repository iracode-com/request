<?php if($isContextMenuEnabled()): ?>
    <div
        
        wire:ignore
        x-data="contextMenuComponent()"
        x-init="init()"
        @contextmenu="contextMenuToggle($event)"
        @close-other-menus.window="handleCloseOtherMenus($event)"
        @close-children-context-menu.window="contextMenuOpen = false"
        class="relative w-full">

    <div>
        <?php echo $__env->make($getMainView(), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

        <template x-teleport="body">
            <div x-show="contextMenuOpen" @click.away="contextMenuOpen = false" x-ref="contextmenu" class="z-50 min-w-48 max-w-2xl text-neutral-800 rounded-md ring-1 ring-gray-950/5 transition bg-white text-sm fixed p-2 shadow-md dark:text-gray-200 dark:bg-gray-900 dark:ring-white/10" x-cloak>
                <?php $__currentLoopData = $getContextMenuActions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($action->isVisible()): ?>
                        <?php if($action instanceof \AymanAlhattami\FilamentContextMenu\ContextMenuDivider): ?>
                            <?php if (isset($component)) { $__componentOriginal38eac5459665cb46e06ef7bb709ca051 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal38eac5459665cb46e06ef7bb709ca051 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-context-menu::components.divider','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-context-menu::divider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal38eac5459665cb46e06ef7bb709ca051)): ?>
<?php $attributes = $__attributesOriginal38eac5459665cb46e06ef7bb709ca051; ?>
<?php unset($__attributesOriginal38eac5459665cb46e06ef7bb709ca051); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal38eac5459665cb46e06ef7bb709ca051)): ?>
<?php $component = $__componentOriginal38eac5459665cb46e06ef7bb709ca051; ?>
<?php unset($__componentOriginal38eac5459665cb46e06ef7bb709ca051); ?>
<?php endif; ?>
                        <?php endif; ?>

                        <?php if($action instanceof Filament\Tables\Actions\Action and !$action instanceof \AymanAlhattami\FilamentContextMenu\ContextMenuDivider): ?>
                            <?php if($action->isVisible()): ?>
                                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                            'context-menu-filament-action flex gap-x-4 select-none group justify-between rounded px-2 py-1.5 hover:bg-neutral-100 outline-none pl-8 data-[disabled]:opacity-50 data-[disabled]:pointer-events-none dark:hover:bg-white/5',
                            'mt-1' => !$loop->first
                        ]); ?>">
                                    <?php echo e($action); ?>

                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </template>
    </div>

    <script>
        function contextMenuComponent() {
            return {
                contextMenuOpen: false,

                contextMenuToggle: function(event) {
                    event.preventDefault();
                    event.stopPropagation();
                    this.contextMenuOpen = true;
                    this.$refs.contextmenu.style.opacity = 0;

                    this.$dispatch('close-other-menus', { id: this.$el });
                    this.$dispatch('close-parent-context-menu', { id: this.$el });

                    this.$nextTick(() => {
                        this.$refs.contextmenu.style.opacity = 1;
                        this.calculateContextMenuPosition(event);
                    });
                },

                calculateContextMenuPosition: function(clickEvent) {
                    const menu = this.$refs.contextmenu;
                    const menuHeight = menu.offsetHeight;
                    const menuWidth = menu.offsetWidth;

                    const top = clickEvent.clientY + menuHeight > window.innerHeight ?
                        window.innerHeight - menuHeight :
                        clickEvent.clientY;

                    const left = clickEvent.clientX + menuWidth > window.innerWidth ?
                        clickEvent.clientX - menuWidth :
                        clickEvent.clientX;

                    menu.style.top = `${top}px`;
                    menu.style.left = `${left}px`;
                },

                handleCloseOtherMenus: function(event) {
                    if (event.detail.id !== this.$el) {
                        this.contextMenuOpen = false;
                    }
                },

                init: function() {
                    window.addEventListener('resize', () => { this.contextMenuOpen = false; });
                    // document.addEventListener('close-children-context-menu', () => { this.contextMenuOpen = false; });
                }
            }
        }
    </script>

<?php else: ?>
    <div>
        <?php echo $__env->make($getMainView(), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php endif; ?>
<?php /**PATH E:\Iracode\Projects\request-module\vendor\aymanalhattami\filament-context-menu\resources\views\filament\tables\columns\context-menu-column.blade.php ENDPATH**/ ?>