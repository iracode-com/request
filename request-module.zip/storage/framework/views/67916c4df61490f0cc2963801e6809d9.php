<?php if (isset($component)) { $__componentOriginal6c29f7de7db759fc79566801037354f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6c29f7de7db759fc79566801037354f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-tree::components.actions.action','data' => ['action' => $action,'dynamicComponent' => 'filament::link','iconPosition' => $getIconPosition(),'iconSize' => $getIconSize(),'class' => 'filament-tree-link-action']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-tree::actions.action'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($action),'dynamic-component' => 'filament::link','icon-position' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getIconPosition()),'icon-size' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getIconSize()),'class' => 'filament-tree-link-action']); ?>
    <?php echo e($getLabel()); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6c29f7de7db759fc79566801037354f6)): ?>
<?php $attributes = $__attributesOriginal6c29f7de7db759fc79566801037354f6; ?>
<?php unset($__attributesOriginal6c29f7de7db759fc79566801037354f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6c29f7de7db759fc79566801037354f6)): ?>
<?php $component = $__componentOriginal6c29f7de7db759fc79566801037354f6; ?>
<?php unset($__componentOriginal6c29f7de7db759fc79566801037354f6); ?>
<?php endif; ?>
<?php /**PATH E:\Iracode\Projects\request-module\vendor\solution-forest\filament-tree\resources\views\actions\link-action.blade.php ENDPATH**/ ?>