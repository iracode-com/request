<?php
    $manager = $getRelationManager();
    $isLazy = $isLazy();

    $normalizeRelationManagerClass = function (string | Filament\Resources\RelationManagers\RelationManagerConfiguration $manager): string {
        if ($manager instanceof \Filament\Resources\RelationManagers\RelationManagerConfiguration) {
            return $manager->relationManager;
        }

        return $manager;
    };

    $normalizedManagerClass = $normalizeRelationManagerClass($manager);

    $managerLivewireProperties = ['lazy' => $isLazy, 'ownerRecord' => $this->getRecord(), 'pageClass' => $this::class];
?>


<div>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split($normalizedManagerClass, [...$managerLivewireProperties, ...$manager instanceof \Filament\Resources\RelationManagers\RelationManagerConfiguration ? $manager->properties : []]);

$__html = app('livewire')->mount($__name, $__params, $normalizedManagerClass, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
</div>
<?php /**PATH E:\Iracode\Projects\request-module\vendor\njxqlus\filament-relation-manager-component\resources\views\forms\relation-manager.blade.php ENDPATH**/ ?>