<?php if(app()->environment(config('login-link.allowed_environments'))): ?>
    <form method="POST" action="<?php echo e(route('loginLinkLogin')); ?>">
        <?php echo csrf_field(); ?>

        <input type="hidden" name="email" value="<?php echo e($email); ?>">
        <input type="hidden" name="key" value="<?php echo e($key); ?>">
        <input type="hidden" name="redirect_url" value="<?php echo e($redirectUrl); ?>">
        <input type="hidden" name="guard" value="<?php echo e($guard); ?>">
        <input type="hidden" name="user_attributes" value="<?php echo e(json_encode($userAttributes)); ?>">
        <input type="hidden" name="user_model" value="<?php echo e($userModel); ?>">

        <?php echo $__env->make('login-link::loginLinkButton', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>
<?php endif; ?>
<?php /**PATH E:\Iracode\Projects\request-module\vendor\spatie\laravel-login-link\resources\views\loginLink.blade.php ENDPATH**/ ?>