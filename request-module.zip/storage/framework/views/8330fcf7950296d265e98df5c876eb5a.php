<div class="flex flex-col items-center bg-gray-50 dark:bg-gray-700 rounded-lg p-4 select-none">
    <p class="font-medium text-gray-600 dark:text-white"><?php echo e(__('banner::manager.banner_list_empty_state_title')); ?></p>
    <p class="text-center text-sm mt-2 text-gray-700 dark:text-white"><?php echo e(__('banner::manager.banner_list_empty_state_description')); ?></p>
</div>
<?php /**PATH E:\Iracode\Projects\request-module\vendor\kenepa\banner\resources\views\components\manager\banner-list-empty-state.blade.php ENDPATH**/ ?>