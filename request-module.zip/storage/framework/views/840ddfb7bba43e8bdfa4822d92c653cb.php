<div class="flex items-center justify-between gap-x-3">
    <label class="fi-fo-field-wrp-label inline-flex items-center gap-x-3">
        <span class="text-sm font-medium leading-6 text-gray-950 dark:text-white"><?php echo e($label); ?>

        </span>
    </label>
</div>
<?php /**PATH E:\Iracode\Projects\request-module\resources\views\vendor\filament-combobox\components\box-label.blade.php ENDPATH**/ ?>