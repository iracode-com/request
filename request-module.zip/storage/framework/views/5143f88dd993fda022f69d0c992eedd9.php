<footer class="bottom-0 left-0 z-20 w-full py-2 border-t md:flex md:items-center md:justify-between md:p-6  dark:border-gray-700">
    <span class="text-sm text-gray-500 sm:text-center dark:text-gray-400"><?php echo e(verta()->year); ?> ©
        <a href="#" class="hover:underline"><?php echo e($copyright); ?></a>
    </span>
</footer><?php /**PATH E:\Iracode\Projects\request-module\resources\views\filament\pages\footer.blade.php ENDPATH**/ ?>