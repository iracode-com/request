<!--[if BLOCK]><![endif]--><?php if(method_exists(static::class, 'getContextMenuActions')): ?>
    <!--[if BLOCK]><![endif]--><?php if(static::isContextMenuEnabled()): ?>
        <div id="contextMenu"
             class="flex z-50 min-w-48 max-w-2xl text-neutral-800 rounded-md ring-1 ring-gray-950/5 transition bg-white text-sm fixed p-2 shadow-md dark:text-gray-200 dark:bg-gray-900 dark:ring-white/10"
             style="display: none;">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = static::getCachedContextMenuActions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!--[if BLOCK]><![endif]--><?php if($action->isVisible()): ?>
                    <!--[if BLOCK]><![endif]--><?php if($action instanceof \AymanAlhattami\FilamentContextMenu\ContextMenuDivider): ?>
                        <?php if (isset($component)) { $__componentOriginal38eac5459665cb46e06ef7bb709ca051 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal38eac5459665cb46e06ef7bb709ca051 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-context-menu::components.divider','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-context-menu::divider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal38eac5459665cb46e06ef7bb709ca051)): ?>
<?php $attributes = $__attributesOriginal38eac5459665cb46e06ef7bb709ca051; ?>
<?php unset($__attributesOriginal38eac5459665cb46e06ef7bb709ca051); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal38eac5459665cb46e06ef7bb709ca051)): ?>
<?php $component = $__componentOriginal38eac5459665cb46e06ef7bb709ca051; ?>
<?php unset($__componentOriginal38eac5459665cb46e06ef7bb709ca051); ?>
<?php endif; ?>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <!--[if BLOCK]><![endif]--><?php if($action instanceof \Filament\Actions\Action and !$action instanceof \AymanAlhattami\FilamentContextMenu\ContextMenuDivider): ?>
                        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'context-menu-filament-action flex gap-x-4 select-none group justify-between rounded px-2 py-1.5 hover:bg-neutral-100 outline-none pl-8 data-[disabled]:opacity-50 data-[disabled]:pointer-events-none dark:hover:bg-white/5',
                        'mt-1' => !$loop->first
                    ]); ?>">
                            <?php echo e($action); ?>

                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <script>
            document.addEventListener('livewire:navigated', function () {
                var contextMenu = document.getElementById('contextMenu');
                var contextMenuTrigger = document.getElementsByClassName('fi-main')[0];

                document.addEventListener('close-parent-context-menu', function(event) {
                    contextMenu.style.display = 'none'; // Show the context menu
                    contextMenu.style.opacity = '0';
                })

                contextMenuTrigger.addEventListener('contextmenu', function (event) {
                    event.preventDefault();
                    contextMenu.style.display = 'block'; // Show the context menu
                    contextMenu.style.opacity = '0';

                    let closeChildrenContextMenu = new Event('close-children-context-menu');
                    dispatchEvent(closeChildrenContextMenu);

                    setTimeout(function () {
                        calculateContextMenuPosition(event);
                        contextMenu.style.opacity = '1';
                    }, 0); // Similar to $nextTick
                });

                document.addEventListener('click', function (event) {
                    if (!contextMenu.contains(event.target)) {
                        contextMenu.style.display = 'none'; // Hide the context menu
                    }
                });

                window.addEventListener('resize', function (event) {
                    contextMenu.style.display = 'none';
                });

                function calculateContextMenuPosition(clickEvent) {
                    var menuHeight = contextMenu.offsetHeight;
                    var menuWidth = contextMenu.offsetWidth;

                    var top = window.innerHeight < clickEvent.clientY + menuHeight ?
                        (window.innerHeight - menuHeight) : clickEvent.clientY;
                    var left = window.innerWidth < clickEvent.clientX + menuWidth ?
                        (clickEvent.clientX - menuWidth) : clickEvent.clientX;

                    contextMenu.style.top = top + 'px';
                    contextMenu.style.left = left + 'px';
                }
            });
        </script>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php /**PATH E:\Iracode\Projects\request-module\vendor\aymanalhattami\filament-context-menu\src\/../resources/views/components/context-menu.blade.php ENDPATH**/ ?>