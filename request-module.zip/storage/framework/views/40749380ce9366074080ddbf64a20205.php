<div
    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
        'mt-4' => $banner->getLocation() === 'panel',
        '' => $banner->getLocation() === 'body',
        '' => $banner->getLocation() === 'nav',
        '' => $banner->getLocation() === 'global_search',
    ]); ?>"
>
    <?php if($banner->isVisible()): ?>
        <?php
            $start_color = $banner->start_color;
            $end_color = '';
            $target = null;

            if (isset($banner->link_click_action) && $banner->link_click_action === 'clickable_banner') {

                $target = $banner->link_open_in_new_tab ? '_blank' : '_self';
            }

            if ($banner->background_type === 'gradient') {
                $end_color = $banner->end_color;
            } else {
                $end_color = $banner->start_color;
            }
        ?>
        <div
            <?php if($target): ?>
                @click="openLink()"
                class="hover:opacity-80 cursor-pointer"
                x-data="{
                    openLink() {
                        window.open('<?php echo e($banner->link_url); ?>', <?php echo e($target ? "'$target'" : '_self'); ?>);
                    },
                }"
            <?php endif; ?>
        >
            <div
                x-title="banner-component"
                x-cloak
                x-show="show"
                x-data="{
                show: true,
                storageKey: 'kenepa-banners::closed',
                init() {
                    this.hasBeenClosedByUser();
                },
                close() {
                    this.show = false;
                    let storedBanners = localStorage.getItem(this.storageKey)
                    storedBanners = JSON.parse(storedBanners)

                    if (storedBanners) {
                        storedBanners.push(this.bannerId)
                        localStorage.setItem(this.storageKey, JSON.stringify(storedBanners))
                    } else {
                        let banners = [this.bannerId]
                        localStorage.setItem(this.storageKey, JSON.stringify(banners));
                    }
                },
                hasBeenClosedByUser() {
                    let storedBanners = localStorage.getItem(this.storageKey)
                    console.log(storedBanners, this.bannerId)

                    if (storedBanners) {
                        let parsedBanners = JSON.parse(storedBanners);
                        if (parsedBanners.indexOf(this.bannerId) > -1) {
                            this.show = false;
                        }
                    }
                },
                bannerId: '<?php echo e($banner->id); ?>',
            }"
                style="background-color: <?php echo e($banner->start_color); ?>; background-image: linear-gradient(to right, <?php echo e($start_color); ?>, <?php echo e($end_color); ?>) ;color: <?php echo e($banner->text_color ?? '#FFFFFF'); ?>;"
                id="<?php echo e($banner->id); ?>"
                class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                   'grid grid-cols-12 pl-6 py-2 pr-8',
                   'rounded-lg' => $banner->render_location !== \Filament\View\PanelsRenderHook::BODY_START
                ]); ?>">
                <div class="col-span-10 flex items-center">
                    <div>
                        <?php if($banner->icon): ?>
                            <?php if (isset($component)) { $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.icon','data' => ['alias' => 'banner::close','icon' => $banner->icon,'style' => 'color: '.e($banner->icon_color ?? '#FFFFFF').'','class' => 'h-6 w-6 mr-2 text-gray-500 dark:text-gray-400 text-white']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['alias' => 'banner::close','icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($banner->icon),'style' => 'color: '.e($banner->icon_color ?? '#FFFFFF').'','class' => 'h-6 w-6 mr-2 text-gray-500 dark:text-gray-400 text-white']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $attributes = $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $component = $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div>
                        <?php echo $banner->content; ?>

                    </div>
                </div>
                <div class="col-span-2 flex justify-end items-center">
                    <?php if(isset($banner->link_active) && $banner->link_active && $banner->link_click_action === "button"): ?>
                        <div class="flex space-x-2 hover:opacity-75 <?php echo e($banner->can_be_closed_by_user ? 'mr-4' : ''); ?>">
                            <div>
                                <?php if($banner->link_button_style === 'button'): ?>
                                    <div>
                                        <a
                                            href="<?php echo e($banner->link_url); ?>"
                                            style="color: <?php echo e($banner->link_text_color ?? '#FFFFFF'); ?>; background-color: <?php echo e($banner->link_button_color ?? '#D97706'); ?>;"
                                            class="hover:bg-blue-800 font-medium rounded-lg text-sm px-3 py-1 focus:outline-none whitespace-nowrap flex items-center"
                                            target="<?php echo e($banner->link_open_in_new_tab ? '_blank' : '_self'); ?>"
                                        >

                                            <?php echo e($banner->link_text); ?>


                                            <?php if($banner->link_button_icon): ?>
                                                <?php if (isset($component)) { $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.icon','data' => ['alias' => 'banner::close','icon' => $banner->link_button_icon,'style' => 'color: '.e($banner->link_button_icon_color ?? '#FFFFFF').'','class' => 'h-5 w-5 text-gray-500 ml-1 dark:text-gray-400 text-white']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['alias' => 'banner::close','icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($banner->link_button_icon),'style' => 'color: '.e($banner->link_button_icon_color ?? '#FFFFFF').'','class' => 'h-5 w-5 text-gray-500 ml-1 dark:text-gray-400 text-white']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $attributes = $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $component = $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
                                            <?php endif; ?>

                                        </a>
                                    </div>
                                <?php endif; ?>

                                <?php if($banner->link_button_style === 'link'): ?>
                                    <div>
                                        <a
                                            style="color: <?php echo e($banner->link_text_color ?? '#FFFFFF'); ?>;"
                                            href="<?php echo e($banner->link_url); ?>"
                                            class="underline font-bold whitespace-nowrap flex items-center"
                                            target="<?php echo e($banner->link_open_in_new_tab ? '_blank' : '_self'); ?>"
                                        >

                                            <?php echo e($banner->link_text); ?>


                                            <?php if($banner->link_button_icon): ?>
                                                <?php if (isset($component)) { $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.icon','data' => ['alias' => 'banner::close','icon' => $banner->link_button_icon,'style' => 'color: '.e($banner->link_button_icon_color ?? '#FFFFFF').'','class' => 'h-5 w-5 text-gray-500 ml-1 dark:text-gray-400 text-white']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['alias' => 'banner::close','icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($banner->link_button_icon),'style' => 'color: '.e($banner->link_button_icon_color ?? '#FFFFFF').'','class' => 'h-5 w-5 text-gray-500 ml-1 dark:text-gray-400 text-white']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $attributes = $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $component = $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
                                            <?php endif; ?>
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if($banner->can_be_closed_by_user): ?>
                        <?php if (isset($component)) { $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.icon','data' => ['@click.stop' => 'close','alias' => 'banner::close','icon' => 'heroicon-m-x-mark','class' => 'h-6 w-6 text-gray-500 dark:text-gray-400 text-white cursor-pointer hover:opacity-75']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['@click.stop' => 'close','alias' => 'banner::close','icon' => 'heroicon-m-x-mark','class' => 'h-6 w-6 text-gray-500 dark:text-gray-400 text-white cursor-pointer hover:opacity-75']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $attributes = $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $component = $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH E:\Iracode\Projects\request-module\vendor\kenepa\banner\resources\views\components\banner.blade.php ENDPATH**/ ?>